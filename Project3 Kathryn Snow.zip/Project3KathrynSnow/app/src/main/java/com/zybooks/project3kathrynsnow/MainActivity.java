package com.zybooks.project3kathrynsnow;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {


        TextView username = (TextView) findViewById(R.id.username);
        TextView password = (TextView) findViewById(R.id.password);

        MaterialButton loginbtn = (MaterialButton) findViewById(R.id.loginbtn);
        //admin    admin

        loginbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {
                    //correct
                    Toast.makeText(MainActivity.this,
                            "LOGIN SUCCESS",
                            Toast.LENGTH_SHORT).show();
                } else {
                    //incorrect
                    Toast.makeText(MainActivity.this,
                            "LOGIN FAILURE",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
        MaterialButton addBtn = findViewById(R.id.addbtn);
        addBtn.setOnClickListener(new View.onClickListener(){

    })
    }
}