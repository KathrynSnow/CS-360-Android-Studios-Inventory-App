package com.zybooks.project3kathrynsnow;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class Database extends AppCompatActivity {
    private ArrayList<String> data1= new ArrayList<String>();
    private ArrayList<String>data2= new ArrayList<String>();
    private ArrayList<String>data3= new ArrayList<String>();
    private ArrayList<String>data4= new ArrayList<String>();

    private TableLayout table;

    EditText ed1, ed2, ed3, ed4;
    Button b1;
    Button b2;
    private int increase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database);

        ed1 = findViewById(R.id.ed1);
        ed2 = findViewById(R.id.ed2);
        ed3 = findViewById(R.id.ed3);
        ed4 = findViewById(R.id.ed4);

        b1 = findViewById(R.id.btn1);
        b2 = findViewById(R.id.btn2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                subtract();
            }
        });
    }
    public void add() {
        int total;
        String prodname = ed1.getText().toString();
        int Quantity = Integer.parseInt(ed2.getText().toString());
        int increase = Integer.parseInt(ed3.getText().toString());
        int decrease = Integer.parseInt(ed4.getText().toString());

        total = Quantity + increase;
        data1.add(prodname);
        data2.add(String.valueOf(Quantity));

        TableLayout table = (TableLayout) findViewById(R.id.tb1);

        TableRow row = new TableRow(this);
        TableRow row1 = new TableRow(this);
        TableRow row2 = new TableRow(this);
        TableRow row3 = new TableRow(this);
        TableRow row4 = new TableRow(this);

        String tot;
        int sum = 0;
        for (int i = 0; i < data2.size(); i++) {
            String pname = data1.get(i);
            String quantity = data2.get(i);
            increase = Integer.parseInt(data3.get(i));
            decrease = Integer.parseInt(data4.get(i));

            t1.setText(pname);
            t2.setText(quantity);
            t3.setText(increase);
            t4.setText(decrease);

            nTotal = sum + data3;
        }
        row.addView(t1);
        row.addView(t2);
        row.addView(t3);
        row.addView(t4);
        table.addView(row);

        ed1.setText(String.valueOf(sum));
        ed2.setText(" ");
        ed3.setText(" ");
        ed4.setText(" ");

        ed1.requestFocus();
    }
    public void subtract() {
        int total;
        String prodname = ed1.getText().toString();
        int Quantity = Integer.parseInt(ed2.getText().toString());

        TableLayout table = (TableLayout) findViewById(R.id.tb1);

        data1.add(prodname);
        data2.add(String.valueOf(Quantity));


        for (int i = 0; i < data2.size(); i--) {
            String pname = data1.get(i);
            Quantity = Integer.parseInt(ed2.getText().toString());
            int increase = Integer.parseInt(ed3.getText().toString());
            int decrease = Integer.parseInt(ed4.getText().toString());

            t1.setText(pname);
            t2.setText(Quantity);
            t3.setText(increase);
            t4.setText(decrease);

            total = data2 - decrease;
        }
        row.removeView(t1);
        row.removeView(t2);
        row.removeView(t3);
        row.removeView(t4);
        table.removeView(row);

        ed1.setText(String.valueOf(decrease));
        ed2.setText(" ");
        ed3.setText(" ");
        ed4.setText(" ");

        ed1.requestFocus();
    }

}
